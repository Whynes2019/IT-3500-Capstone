﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Hynes.CapstoneDesign03
{
    class ConverterDesign
    {
        ConverterDesign()
        {
            private int EnterOnes(int Ones)// enter ones numbers
        {

        }
            private int EnterTeens(int Teens)// enter hundreds numbers
            {

            }
            private int EnterHundreds(int Hundreds)// enter Hundreds numbers
            {

            }
            private int EnterThousands(int Thousands)// enter thousands numbers
            {

            }
            private int EnterMillions(int Millions)// enter ones numbers
            {

            }
            public void ExitProgram//exits the program.  
        }
    }
}
