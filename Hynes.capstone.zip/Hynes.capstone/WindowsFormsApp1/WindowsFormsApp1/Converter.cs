﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Converter : Form
    {
        public Converter()
        {
            InitializeComponent();
        }

        private void btnConvert_Click(object sender, EventArgs e)
        {
            lblNumberInWords.Text = "";

            Hynes.CapstoneApplication04.CreateBillionsMillionsThousandsHundredsCentsStrings breakIntoParts
                    = new Hynes.CapstoneApplication04.CreateBillionsMillionsThousandsHundredsCentsStrings(txtInputNumbers.Text);
            String[] inPieces = breakIntoParts.getInputBrokenIntoPieces();

            for (int n = 0; n < inPieces.Length; n++)
            {
                if (inPieces[n] != null)
                {
                    Hynes.CapstoneApplication04.Convert toWords
                        = new Hynes.CapstoneApplication04.Convert(inPieces[n]);
                    lblNumberInWords.Text += toWords.getNumberInWords();
                    switch(n)
                        {
                        case 0:
                            lblNumberInWords.Text += " billions ";
                            break;
                        case 1:
                            lblNumberInWords.Text += " millions ";
                            break;
                        case 2:
                            lblNumberInWords.Text += " thousands ";
                            break;
                        case 3:
                            lblNumberInWords.Text += " hundreds ";
                            break;
                        case 4:
                            lblNumberInWords.Text += " dollars ";
                            break;
                        case 1:
                            lblNumberInWords.Text += " cents ";
                            break;
                    }
                }
            }
        }
    }
}
