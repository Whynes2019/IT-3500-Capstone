﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Hynes.CapstoneApplication04
{
    class Convert
    {
        private string numberInWords = "";

        public Convert(String workingString)
        {
            if (workingString == null || workingString.Length == 0 || workingString.Length > 3)
            {
                numberInWords = null;
                return;
            }

            if (workingString.Length == 3)
                numberInWords += OnesAndHundreds(workingString[0]);
            if (workingString.Length > 1)
                numberInWords += Tens(workingString);
            int tensDigit = 1;
            if (workingString.Length == 2)
                tensDigit = 0;
            if (workingString[tensDigit] != 1)
            {
                int onesDigit = 2;
                if (workingString.Length == 2)
                    onesDigit = 1;
                if (workingString.Length == 1)
                    onesDigit = 0;
                numberInWords += OnesAndHundreds(workingString[onesDigit]);
            }
        }

        public string getNumberInWords()
        {
            return numberInWords;
        }

        private string OnesAndHundreds(char num)
        {
            switch (num)
            {
                case '1':
                    return "One";
                case '2':
                    return "Two";
                case '3':
                    return "Three";
                case '4':
                    return "Four";
                case '5':
                    return "Five";
                case '6':
                    return "Six";
                case '7':
                    return "Seven";
                case '8':
                    return "Eight";
                case '9':
                    return "Nine";
                default:
                    return null;
            }
        }

        private string Tens(String Num)
        {
            int tensChar = 1;
            if (Num.Length == 2)
                tensChar = 0;

            switch (Num[tensChar])
            {
                case '1':
                    {
                        switch (Num[tensChar + 1])
                        {
                            case '0':
                                return "ten";
                            case '1':
                                return "eleven";
                            case '2':
                                return "twelve";
                            case '3':
                                return "thirteen";
                            case '4':
                                return "fourteen";
                            case '5':
                                return "fifteen";
                            case '6':
                                return "sixteen";
                            case '7':
                                return "seventeen";
                            case '8':
                                return "eighteen";
                            case '9':
                                return "nineteen";
                            default:
                                return null;
                        }
                    }
                case '2':
                    return "twenty";
                case '3':
                    return "thirty";
                case '4':
                    return "fourty";
                case '5':
                    return "fifty";
                case '6':
                    return "sixty";
                case '7':
                    return "seventy";
                case '8':
                    return "eighty";
                case '9':
                    return "ninty";
                default:
                    return null;
            }
        }
    }
}