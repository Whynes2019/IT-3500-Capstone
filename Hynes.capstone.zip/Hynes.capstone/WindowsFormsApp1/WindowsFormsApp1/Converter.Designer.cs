﻿
namespace WindowsFormsApp1
{
    partial class Converter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtInputNumbers = new System.Windows.Forms.TextBox();
            this.lblNumberInWords = new System.Windows.Forms.Label();
            this.btnConvert = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtInputNumbers
            // 
            this.txtInputNumbers.Location = new System.Drawing.Point(347, 167);
            this.txtInputNumbers.Multiline = true;
            this.txtInputNumbers.Name = "txtInputNumbers";
            this.txtInputNumbers.Size = new System.Drawing.Size(156, 28);
            this.txtInputNumbers.TabIndex = 0;
            // 
            // lblNumberInWords
            // 
            this.lblNumberInWords.Location = new System.Drawing.Point(64, 294);
            this.lblNumberInWords.Name = "lblNumberInWords";
            this.lblNumberInWords.Size = new System.Drawing.Size(635, 29);
            this.lblNumberInWords.TabIndex = 1;
            // 
            // btnConvert
            // 
            this.btnConvert.Location = new System.Drawing.Point(347, 224);
            this.btnConvert.Name = "btnConvert";
            this.btnConvert.Size = new System.Drawing.Size(75, 23);
            this.btnConvert.TabIndex = 2;
            this.btnConvert.Text = "convert";
            this.btnConvert.UseVisualStyleBackColor = true;
            this.btnConvert.Click += new System.EventHandler(this.btnConvert_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnConvert);
            this.Controls.Add(this.lblNumberInWords);
            this.Controls.Add(this.txtInputNumbers);
            this.Name = "Form1";
            this.Text = "convert";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtInputNumbers;
        private System.Windows.Forms.Label lblNumberInWords;
        private System.Windows.Forms.Button btnConvert;
    }
}

